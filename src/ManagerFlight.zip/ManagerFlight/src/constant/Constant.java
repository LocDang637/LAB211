/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package constant;

/**
 *
 * @author ADMIN
 */
public class Constant {

    public static final String FORMAT_DATE = "HH:mm dd/MM/yyyy";
    public static final String BIRTHDAY = "dd/MM/yyyy";
    public static final String FILE = "product.dat";
    public static final int CHECK_IN = 1;
    public static final int NOT_CHECK_IN = 0;
    public static final String PILOT = "PILOT";
    public static final String FLIGHT_ATTENDANT = "FLIGHT ATTENDANT";
    public static final String GROUND_STAFF = "GROUND STAFF";

}
